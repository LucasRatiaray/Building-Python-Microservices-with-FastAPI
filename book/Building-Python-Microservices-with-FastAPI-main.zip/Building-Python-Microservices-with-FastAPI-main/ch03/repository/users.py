login_details = dict()
user_profiles = dict()


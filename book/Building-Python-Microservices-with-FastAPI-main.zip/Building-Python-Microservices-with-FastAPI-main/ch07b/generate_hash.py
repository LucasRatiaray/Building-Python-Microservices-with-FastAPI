from base64 import urlsafe_b64encode

h = urlsafe_b64encode(b"sjctrags:sjctrags")
print(h)
#  c2pjdHJhZ3M6c2pjdHJhZ3M=
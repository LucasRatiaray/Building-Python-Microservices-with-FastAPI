from pony.orm import  Database

db = Database("postgres", host="localhost", port="5433", user="postgres", password="admin2255", database="fcms")
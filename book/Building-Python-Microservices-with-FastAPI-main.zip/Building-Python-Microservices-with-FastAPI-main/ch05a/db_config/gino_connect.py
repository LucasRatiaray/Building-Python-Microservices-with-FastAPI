from gino import Gino

db = Gino()


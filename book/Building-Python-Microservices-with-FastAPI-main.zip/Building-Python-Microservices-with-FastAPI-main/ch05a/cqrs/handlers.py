
class IQueryHandler: 
    pass 

class ICommandHandler: 
    pass
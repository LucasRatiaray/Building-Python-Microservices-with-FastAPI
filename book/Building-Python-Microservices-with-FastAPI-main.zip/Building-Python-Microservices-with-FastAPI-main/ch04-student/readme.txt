=========================== Basic Details ==================================
Application Name: University ERP System (Student Microservice)
Developer: Sherwin John Calleja Tragura
Status: Prototype stage
Date finished: July 19, 2022

=========================== Description ====================================

This prototype is the student microservice application which is part of the 
whole University ERP. This application can be run, managed, and deployed 
separately from the others using a different URL address and port.  

Please refer to project ch04 for the backup database and requirements.txt.